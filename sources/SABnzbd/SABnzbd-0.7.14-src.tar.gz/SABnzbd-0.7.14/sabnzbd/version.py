# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "trunk" or "0.4.x")

# You MUST use double quotes (so " and not ')

__version__ = "0.7.14"
__baseline__ = "bc9be3f92b506f8a529213a5f2d989802f4d00b1"
