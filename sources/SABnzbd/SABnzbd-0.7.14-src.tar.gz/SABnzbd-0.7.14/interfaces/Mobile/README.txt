
Mobile 0.1 for SABnzbd 0.6 | Sept 01 2009
assembled by pairofdimes - see LICENSE-CC.txt

==============
LIBRARIES USED

jQuery
http://jquery.com
Copyright (c) 2010 John Resig
See LICENSE-MIT & LICENSE-GPL

Sizzle CSS Selector Engine
http://sizzlejs.com/
Copyright (c) 2010 The Dojo Foundation
See LICENSE-MIT, LICENSE-BSD, & LICENSE-GPL

jQuery jQTouch Plugin
http://www.jqtouch.com/
Copyright (c) 2009 jQTouch project members
See LICENSE-MIT

The image templates/static/images/sab.png was provided by inpheaux.

All other images and stylesheets provided by jQuery jQTouch Plugin package (see notes above).
